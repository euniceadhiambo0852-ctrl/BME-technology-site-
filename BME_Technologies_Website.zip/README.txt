BME TECHNOLOGIES WEBSITE

Files:
- index.html: complete responsive website. Open it in a browser to preview.

To publish for free:
1. Create/sign in to a GitHub account.
2. Create a public repository named bme-technologies-site.
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select main and /(root), then Save.
7. GitHub will provide the public website URL after deployment.

Before public launch:
- Confirm legal company name and trademark availability.
- Replace the general WhatsApp contact link with the founder's business number if desired.
- Add verified company contact details and privacy information before collecting user data.
- BME ONE is described as a concept; do not present it as a launched product yet.
